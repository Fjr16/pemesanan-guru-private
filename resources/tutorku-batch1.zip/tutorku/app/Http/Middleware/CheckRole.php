<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * Middleware: CheckRole
 *
 * Memastikan user yang sedang login memiliki role yang sesuai.
 * Penggunaan di route: ->middleware('role:siswa') / 'role:tutor' / 'role:admin'
 *
 * Didaftarkan di bootstrap/app.php (Laravel 11) atau Kernel.php (Laravel 10):
 *   'role' => \App\Http\Middleware\CheckRole::class,
 */
class CheckRole
{
    public function handle(Request $request, Closure $next, string ...$roles): mixed
    {
        if (! Auth::check()) {
            return redirect()->route('login')
                ->with('warning', 'Silakan login terlebih dahulu.');
        }

        $user = Auth::user();

        // Izinkan jika salah satu role cocok
        if (in_array($user->role, $roles, true)) {
            return $next($request);
        }

        // Redirect ke dashboard yang sesuai
        return match($user->role) {
            'admin'  => redirect()->route('admin.dashboard')
                            ->with('error', 'Akses ditolak. Anda tidak memiliki izin.'),
            'tutor'  => redirect()->route('tutor.dashboard')
                            ->with('error', 'Akses ditolak. Anda tidak memiliki izin.'),
            default  => redirect()->route('siswa.dashboard')
                            ->with('error', 'Akses ditolak. Anda tidak memiliki izin.'),
        };
    }
}
